<!DOCTYPE html>
<html>
<head>
<title>Payment</title>
<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "dbproject");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$id = mysqli_real_escape_string($link, $_REQUEST['id']);
$sub_device = mysqli_real_escape_string($link, $_REQUEST['sub_device']);
$sub_type = mysqli_real_escape_string($link, $_REQUEST['sub_type']);
$sub_fee = mysqli_real_escape_string($link, $_REQUEST['sub_fee']);
$start_date = date("Y-m-d");
    $current = date("m",strtotime($start_date));
    $next = date("m",strtotime($start_date."+1 month"));
    if($current==$next-1){
        $end_date = date('Y-m-d',strtotime($start_date." +1 month"));
    }else{
        $end_date = date('Y-m-d', strtotime("last day of next month",strtotime($start_date)));
    }
$sql = "INSERT INTO subscription_user (id, sub_device, sub_type,sub_fee,start_date,end_date) VALUES ('$id', '$sub_device', '$sub_type','$sub_fee','$start_date','$end_date')";
if(mysqli_query($link, $sql)){
	$last_id = mysqli_insert_id($link);
	echo "<h3>Registration completed!<br>";
	echo "<br>Click to print <a href='receipt-connect.php' target='popup' >receipt</a></br>";
	echo "<br>Proceed to <a href='login.php'>login</a></div>.</h3>";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
</html>