<?php
//db connection
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'dbproject');
?>

<html>
	<head>
		<title>Receipt generator</title>
<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
	</head>
	
	<body>
	<h1>TMFLIX</h1>
	<div>
		select Member ID:
		
		<form method='get' action='receipt.php'>
			<select class="formStyle" name='id'>
				<?php
					//show invoices list as options
					$query = mysqli_query($con,"select * from users");
					while($users = mysqli_fetch_array($query)){
						echo "<option value='".$users['id']."'>".$users['id']."</option>";
					}
				?>
			</select>
			<input class="formButton" type='submit' value='Generate Receipt'>
		</form>
		</div>
	</body>
</html>