<?php

require_once ("database2.php");
function inputElement($icon, $placeholder, $name, $value){
    $ele = "
        
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\">s
            <div class=\"input-group-text bg-warning\">$icon</div>
            </div>
            <input type=\"text\" name='$name' value='$value'  placeholder='$placeholder' class=\"form-control\" id=\"inlineFormInputGroup\" placeholder=\"Username\">
        </div>
    
    ";
    echo $ele;
}

function buttonElement($btnid, $styleclass, $text, $name, $attr){
    $btn = "
        <button name='$name' '$attr' class='$styleclass' id='$btnid'>$text</button>
    ";
    echo $btn;
}

$con = Createdb();

//For CRUD selection buttons
if(isset($_POST['create'])){
    createData();
}

if(isset($_POST['update'])){
    UpdateData();
}

if(isset($_POST['delete'])){
    deleteRecord();
}

if(isset($_POST['deleteall'])){
    deleteAll();

}

//Function to insert/create new record
function createData(){
    $seriesid = textboxValue("series_id");
    $seriesname = textboxValue("series_name");
    $seriesseason = textboxValue("series_season");
    $seriesepisode = textboxValue("series_episode");
    $serieseptitle = textboxValue("series_ep_title");

    if($seriesid && $seriesname && $seriesseason && $seriesepisode && $serieseptitle){

        $sql = "INSERT INTO episode (series_id, series_name, series_season, series_episode, series_ep_title) 
                        VALUES ('$seriesid','$seriesname','$seriesseason','$seriesepisode','$serieseptitle')";

        if(mysqli_query($GLOBALS['con'], $sql)){
            TextNode("success", "Series Data Saved Successfully...!");
        }else{
            echo "Error";
        }

    }else{
            TextNode("error", "Please Insert Series Data To Proceed");
    }
}

function textboxValue($value){
    $textbox = mysqli_real_escape_string($GLOBALS['con'], trim($_POST[$value]));
    if(empty($textbox)){
        return false;
    }else{
        return $textbox;
    }
}

//Function to display misc. error/success messages
function TextNode($classname, $msg){
    $element = "<h6 class='$classname'>$msg</h6>";
    echo $element;
}

//Retrieve data from mysql
function getData(){
    $sql = "SELECT * FROM episode";

    $result = mysqli_query($GLOBALS['con'], $sql);

    if(mysqli_num_rows($result) > 0){
        return $result;
    }
}

//Function to edit/modify data
function UpdateData(){
    $num = textboxValue("number");
    $seriesid = textboxValue("series_id");
    $seriesname = textboxValue("series_name");
    $seriesseason = textboxValue("series_season");
    $seriesepisode = textboxValue("series_episode");
    $serieseptitle = textboxValue("series_ep_title");

    if($seriesid && $seriesname && $seriesseason && $seriesepisode && $serieseptitle){
        $sql = "
            UPDATE episode SET series_id='$seriesid', series_name='$seriesname', series_season ='$seriesseason', series_episode ='$seriesepisode', series_ep_title = '$serieseptitle' WHERE no='$num';                   
        ";

        if(mysqli_query($GLOBALS['con'], $sql)){
            TextNode("success", "Data Successfully Updated");
        }else{
            TextNode("error", "Enable to Update Data");
        }

    }else{
        TextNode("error", "Please Click On The Edit Button Of The Series Record");
    }
}

//Function to delete data
function deleteRecord(){
    $num = (int)textboxValue("number");

    $sql = "DELETE FROM episode WHERE no=$num";

    if(mysqli_query($GLOBALS['con'], $sql)){
        TextNode("success","Series Data Deleted Successfully...!");
    }else{
        TextNode("error","Enable to Delete Record...!");
    }

}


function deleteBtn(){
    $result = getData();
    $i = 0;
    if($result){
        while ($row = mysqli_fetch_assoc($result)){
            $i++;
            if($i > 3){
                buttonElement("btn-deleteall", "btn btn-danger" ,"<i class='fas fa-trash'></i> Delete All", "deleteall", "");
                return;
            }
        }
    }
}

//Function to delete entire record
function deleteAll(){
    $sql = "DROP TABLE episode";

    if(mysqli_query($GLOBALS['con'], $sql)){
        TextNode("success","All Series Data Deleted Successfully...!");
        Createdb();
    }else{
        TextNode("error","Something Went Wrong, Data Cannot Be Deleted...!");
    }
}


//Set number to textbox
function setNum(){
    $getNum = getData();
    $no = 0;
    if($getNum){
        while ($row = mysqli_fetch_assoc($getNum)){
            $no = $row['no'];
        }
    }
    return ($no + 1);
}

