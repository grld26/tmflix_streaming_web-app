<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
	function myFunction() {
	var x = document.getElementById("myPass");
	if (x.type === "password") {
	  x.type = "text";
	} 
	else{
		x.type = "password";
	}
}
</script>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<body>
<?php
require('connect.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])){
        // removes backslashes
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	//Checking is user existing in the database or not
    $query = "SELECT * FROM `users` WHERE username='$username'
and password='".md5($password)."'";
	$result = mysqli_query($con,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['username'] = $username;
            // Redirect user to main.php
	    header("Location: main.php");
         }else{
		echo "<div class='tologin'>
			<h3>Username/password is incorrect.</h3>
			<br/>Click here to <a href='login.php'>Login</a></div>";
		}
    }else{
?>
<a href='adminlogin.php' class="formButton">Admin Login</a> 
<div>
<h1>TMFLIX</h1>
<form action="" method="post" name="login">
	<input type="text" name="username" class="formStyle" placeholder="Username" required />
    <input type="password" id="myPass" name="password" class="formStyle" placeholder="Password" required />
	<div>
		<input type="checkbox" onclick="myFunction()">Show Password
	</div>
	<input type="submit" class="formButton" name="Submit" id="Submit" value="LOGIN">
</form>
<p class='notreg'>Not registered yet? <a href='register.php'>Register Here</a></p>
</div>
<?php } ?>
</body>
</html>