<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dbproject";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
  $con = mysqli_connect("localhost","root","","dbproject");
  include("auth.php");
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TMFlix Main</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['series names', 'views'],
         <?php
         $sql = "SELECT * FROM views";
         $fire = mysqli_query($con,$sql);
          while ($result = mysqli_fetch_assoc($fire)) {
            echo"['".$result['series_name']."',".$result['view_count']."],";
          }
         ?>
        ]);
        var options = { backgroundColor: 'transparent', legendTextStyle: { color: 'white' },
          title: 'Top 5 Viewed Series As of Last Month'
        };
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <p>Welcome <?php echo $_SESSION['username']; ?>!
<br><a href="logout.php">Logout</a></p>
  <body>
    <div class="site-main" id="main">
      <div class="main-content" id="main-content">
        <h1>TMFLIX</h1>
        <div class="content-area" id="primary">
          <div class="search-show">
            <form class="" action="search_show.php" method="POST">
              <input type="text" name="search" placeholder="Search Show">
              <input type="submit" name="search_show" value="Search">
              <br><br>
            </form>
          </div>
          <div class="search-cast">
            <form class="" action="search_cast.php" method="POST">
              <input type="text" name="search" placeholder="Search Cast">
              <input type="submit" name="search_cast" value="Search">
              <br><br>
            </form>
          </div>
          <div class="">
            <form class="" action="dropdown_selection.php" method="POST">
              <select class="" name="value">
                <option value="All Genre">All Genre</option>
                <option value="Crime">Crime</option>
                <option value="Sci-Fi">Sci-Fi</option>
                <option value="Sitcom">Sitcom</option>
                <option value="Mystery">Mystery</option>
                <option value="Comedy">Comedy</option>
                <option value="Historical Fiction">Historical Fiction</option>
                <input type="submit" name="filter_genre" value="Filter">
              </select>
            </form>
            <br><br>
          </div>

          <br><br>
          <div class="row_1">


          <div class="column_new">
            <form class="" action="watch_now.php" method="GET">
              <hr>
              <h2>Newly Added</h2>
              <hr>
              <br><br>
              <?php
                $sql = "SELECT * FROM series ORDER BY id DESC LIMIT 1";
                $result = mysqli_query($conn, $sql);

                if(mysqli_num_rows($result) > 0){
                  while($row = mysqli_fetch_assoc($result)){
                    echo "" . $row["series_name"] . "<br>" . "Genre: " . $row["series_genre"] . "<br>" . "Lead Cast: " . $row["series_cast"] . "<br>" . "Directed By: " . $row["series_director"]
                    . "<br>" . "<br>" . "<a href='watch_now.php?ID={$row['id']}'>Watch Now</a>"
                    . "<br>" . "<br>" . "<br>";
                  }
                }else{
                  echo "0 result";
                }
              ?>
            </form>
          </div>
          <div class="column_top">
            <form class="" action="watch_now.php" method="GET">
              <hr>
              <div class="">
                <span>
                  Top 5 Most Popular!
                </span>
              </div>
              <hr>
              <div id="piechart"></div>
              <br><br>
              <?php
                $sql = "SELECT * FROM views, series WHERE series.id = views.id ORDER BY views.view_count DESC LIMIT 5";
                $result = mysqli_query($conn, $sql);

                if(mysqli_num_rows($result) > 0){
                  while($row = mysqli_fetch_assoc($result)){
                    echo "" . $row["series_name"] . "<br>" . "Genre: " . $row["series_genre"] . "<br>" . "Lead Cast: " . $row["series_cast"] . "<br>" . "Directed By: " . $row["series_director"]
                    . "<br>" . "<br>" . "<a href='watch_now.php?ID={$row['id']}'>Watch Now</a>"
                    . "<br>" . "<br>" . "<br>";
                  }
                }else{
                  echo "0 result";
                }
              ?>
            </form>
          </div>
          <div style="flex: 1">
              <div >
                <div class="icon">
                  <div class="column_show">
                    <hr>
                    <div class="tv-show-content">
                      <span>
                        TV Shows!
                      </span>
                    </div>
                    <hr/>
                      <?php
                        $sql = "SELECT * FROM series";
                        $result = mysqli_query($conn, $sql);

                        if(mysqli_num_rows($result) > 0){
                          while($row = mysqli_fetch_assoc($result)){
                            echo "" . $row["series_name"] . "<br>" . "Genre: " . $row["series_genre"] . "<br>" . "Lead Cast: " . $row["series_cast"] . "<br>" . "Directed By: " . $row["series_director"]
                            . "<br>" . "<br>" . "<a href='watch_now.php?ID={$row['id']}'>Watch Now</a>"
                            . "<br>" . "<br>" . "<br>";
                          }
                        }else{
                          echo "0 result";
                        }
                      ?>
                  </div>
                </div>
              </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </body>
  <style media="screen">
    body{
      color: red;
      text-align: center;
      background-color: black;
      font-family: Bebas Neue;
    }
    a{
      color: white;
    }
    h1 {
    margin-left: auto;
    margin-top: 50px;
    text-align: center;
    font-weight: 100;
    font-size: 3.8em;
    color: #E50914;
    }
    hr{
      border-top: black;
    }
    p {
    margin-top: 1px;
    text-align:left;
    font-weight: 50;
    color: white;
    font-size: 1.2em;
    }

    #piechart{
      width: 600px; 
      height: 200px;
      margin-left: 28%;
      margin-right: 50%;
    }
    /*.column_new{
      float: left;
      width: 33.3%;
      padding: 10px;
      height: 300px;
    }
    .column_chart{
      float: center;
      width: 33.3%;
      padding: 10px;
      height: 300px;
    }
    .column_top{
      float: right;
      width: 33.33%;
      padding: 10px;
      height: 300px;
    }
    .column_show{
      float: ;
      width: 33.33%;
      padding: 10px;
      height: 300px;
    }
    .row_1:after {
      content: "";
      display: table;
      clear: both;*/
}
  </style>
</html>
