<?php
  
// Get the user id 
$sub_id = $_REQUEST['sub_id'];
  
// Database connection
$con = mysqli_connect("localhost", "root", "", "dbproject");
  
if ($sub_id !== "") {
      
    // Get corresponding first name and 
    // last name for that user id    
    $query = mysqli_query($con, "SELECT sub_device, 
    sub_type,sub_fee FROM subscription WHERE sub_id='$sub_id'");
  
    $row = mysqli_fetch_array($query);
  
    // Get the first name
    $sub_device = $row["sub_device"];
  
    // Get the first name
    $sub_type = $row["sub_type"];
	$sub_fee = $row["sub_fee"];
}
  
// Store it in a array
$result = array("$sub_device", "$sub_type", "$sub_fee");
  
// Send in JSON encoded form
$myJSON = json_encode($result);
echo $myJSON;
?>