<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dbproject";

  $conn = mysqli_connect($servername, $username, $password, $dbname);


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>
      <?php
      if(isset($_GET['ID'])){
        $ID = mysqli_real_escape_string($conn, $_GET['ID']);
        $sql = "SELECT * FROM series WHERE id = '$ID'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0){
          while($row = mysqli_fetch_assoc($result)){
            echo "" . $row["series_name"];
          }
        }else{
          echo "0 result";
        }
      }
      ?>
    </title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  </head>
  <body>
    <?php
    if(isset($_GET['ID'])){
      $ID = mysqli_real_escape_string($conn, $_GET['ID']);
      $sql = "SELECT * FROM episode WHERE series_id = '$ID'";
      $result = mysqli_query($conn, $sql);

      if(mysqli_num_rows($result) > 0){
        while($row = mysqli_fetch_assoc($result)){
          echo "Season: " . $row["series_season"] . "<br>" . "Episode " . $row["series_episode"] . ", ". $row["series_ep_title"] . "<br>" . "<br>";
        }
      }else{
        echo "0 result";
      }
    }
    ?>
  </body>
  <style media="screen">
    body{
      color: red;
      text-align: center;
      background-color: black;
      font-family: Bebas Neue;
    }
    a{
      color: white;
    }
  </style>
</html>
<?php
if(isset($_GET['ID'])){
  $ID = mysqli_real_escape_string($conn, $_GET['ID']);
  $sql = "UPDATE views SET view_count = view_count + 1 WHERE id = '$ID'";
  $result = mysqli_query($conn, $sql);
}
?>
