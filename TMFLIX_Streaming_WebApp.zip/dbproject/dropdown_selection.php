<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dbproject";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TMFlix</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="tv-show-content">
      <span>
        TV Shows!
      </span>
    </div>
    <hr/>
    <div class="">
      <form class="" action="watch_now.php" method="post">
        <?php
          if($_POST['value'] == 'Crime'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Crime'";
          }else if($_POST['value'] == 'Sci-Fi'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Sci-Fi'";
          }else if($_POST['value'] == 'Sitcom'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Sitcom'";
          }else if($_POST['value'] == 'Mystery'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Mystery'";
          }else if($_POST['value'] == 'Comedy'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Comedy'";
          }else if($_POST['value'] == 'Historical Fiction'){
            $sql = "SELECT * FROM series WHERE series_genre = 'Historical Fiction'";
          }
          else{
            $sql = "SELECT * FROM series";
          }

          $result = mysqli_query($conn, $sql);
          if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
              echo "" . $row["series_name"] . "<br>" . "Genre: " . $row["series_genre"] . "<br>" . "Lead Cast: " . $row["series_cast"] . "<br>" . "Directed By: " . $row["series_director"]
              . "<br>" . "<br>" . "<a href='watch_now.php?ID={$row['id']}'>Watch Now</a>"
              . "<br>" . "<br>" . "<br>";
            }
          }else{
            echo "0 result";
          }
        ?>
      </form>
    </div>
  </body>
  <style media="screen">
    body{
      color: red;
      text-align: center;
      background-color: black;
      font-family: Bebas Neue;
    }
    a{
      color: white;
    }
  </style>
</html>
