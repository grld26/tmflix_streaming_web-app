<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dbproject";

  $conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TMFlix</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="tv-show-content">
      <span>
        TV Shows!
      </span>
    </div>
    <hr/>
    <div class="">
      <form class="" action="watch_now.php" method="POST">
        <?php
        if(isset($_POST['search_show'])){
          $search = mysqli_real_escape_string($conn, $_POST['search']);
          $sql = "SELECT * FROM series WHERE series_name LIKE '%$search%'";
          $result = mysqli_query($conn, $sql);
          $queryResult = mysqli_num_rows($result);
          if($queryResult > 0){
            while($row = mysqli_fetch_assoc($result)){
              echo "" . $row["series_name"] . "<br>" . "Genre: " . $row["series_genre"] . "<br>" . "Lead Cast: " . $row["series_cast"] . "<br>" . "Directed By: " . $row["series_director"]
              . "<br>" . "<br>" . "<a href='watch_now.php?ID={$row['id']}'>Watch Now</a>"
              . "<br>" . "<br>" . "<br>";
            }
          }else{
            echo "No results";
          }
        }
        ?>
      </form>
    </div>
  </body>
  <style media="screen">
    body{
      color: red;
      text-align: center;
      background-color: black;
      font-family: Bebas Neue;
    }
    a{
      color: white;
    }
  </style>
</html>
