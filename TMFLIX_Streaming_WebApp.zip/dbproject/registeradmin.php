<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
	//function to enable password visibility
	function myFunction() {
	var x = document.getElementById("myPass");
	if (x.type === "password") {
	  x.type = "text";
	} 
	else{
		x.type = "password";
	}
}
</script>
<meta charset="utf-8">
<title>New Admin Registration</title>
<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<body>
<?php
require('connect.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
        // removes backslashes
	$name = stripslashes($_REQUEST['name']);
	$name = mysqli_real_escape_string($con,$name);
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username); 
	
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
    $query = "INSERT into `admins` ( name,email,username, password)
	VALUES ('$name','$email','$username', '".md5($password)."')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='tologin'>
			<h3>New admin registered successfully!</h3>
			<br/>Click here to proceed to <a href='adminlogin.php'>Admin Login</a></div>";
        }
    }else{
?>

<h1>TMFLIX</h1>
<div>
  <form method="post" action="" >
    <input type="text" name="name" class="formStyle" placeholder="New Admin Name" required />
    <input type="email" name="email" class="formStyle" placeholder="New Admin Email" required />
	<input type="text" name="username" class="formStyle" placeholder="New Admin Username" required />
    <input type="password" id="myPass" name="password" class="formStyle" placeholder="New Admin Password" required />
    <div>
		<input type="checkbox" onclick="myFunction()">Show Password
	</div>
	<input type="submit" class="formButton" name="Submit" id="Submit" value="SAVE ADMIN">
  </form>
</div>
<?php } ?>
</body>
</html>