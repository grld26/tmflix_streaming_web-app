<?php
require ('fpdf17/fpdf.php');

//db connection
$con = mysqli_connect ('localhost','root','');
mysqli_select_db ($con, 'dbproject');

//get receipt data

$query = mysqli_query($con, "select * from subscription_user 
		inner join users using (id)
		where 
		id = '".$_GET['id']."'");
$subscription_user = mysqli_fetch_array($query);


$pdf = new FPDF('P', 'mm', 'A4');
$pdf -> AddPage();

//Cell(width , height , text , border , end line , [align] )
$myImage = "TMFlix Logo.png";
$pdf ->Image($myImage, 10, $pdf->GetY(), 32);

$pdf->SetFont('Arial','B',14);
$pdf->Cell(35 ,8,'',0,0);
$pdf->Cell(90 ,8,'TMFlix',0,0);

$pdf->SetFont('Arial','B',24);
$pdf->Cell(59 ,10,'RECEIPT',0,1);

$pdf->SetFont('Arial','',12);

$pdf->Cell(35 ,8,'',0,0);
$pdf->Cell(90 ,8,'TMFlix Corporate Headquarters',0,0);
$pdf->Cell(40 ,8,'',0,0);
$pdf->Cell(59 ,8,'',0,1);

$pdf->Cell(35 ,8,'',0,0);
$pdf->Cell(90 ,8,'93000, Kuching, Sarawak',0,0);
$pdf->Cell(25 ,8,'',0,0);

$pdf->Cell(35 ,8,'',0,1);

$pdf->Cell(35 ,8,'',0,0);
$pdf->Cell(90 ,8,'Fax [+60]123456789',0,0);
$pdf->Cell(25 ,8,'User ID',0,0);
$pdf->Cell(34 ,8,$subscription_user['id'],0,1);

$pdf->Cell(189 ,20,'',0,1); //spacing

//billing address
$pdf->SetFont('Arial','B',14);
$pdf->Cell(100 ,8,'Bill to',0,1);
$pdf->SetFont('Arial','',12);
$pdf->Cell(10 ,8,'',0,0);
$pdf->Cell(90 ,8,$subscription_user['name'],0,1);
$pdf->Cell(10 ,8,'',0,0);
$pdf->Cell(90 ,8,$subscription_user['username'],0,1);
$pdf->Cell(10 ,8,'',0,0);
$pdf->Cell(90 ,8,$subscription_user['email'],0,1);

$pdf->Cell(189 ,10,'',0,1); //spacing

$pdf->SetFont('Arial','B',14);
$pdf->Cell(100 ,10,'TMFlix Subscription Details',0,1, 'C');//end of line

//receipt description details
$pdf->SetFont('Arial','B',12); 
$pdf->Cell(20 ,10,'',0,0);
$pdf->Cell(30 ,10,'Type',1,0);
$pdf->Cell(25 ,10,'Device',1,0);
$pdf->Cell(30 ,10,'Start Date',1,0);
$pdf->Cell(30 ,10,'End Date',1,0);
$pdf->Cell(34 ,10,'Fee (RM)',1,1);

//display the description details
$query = mysqli_query($con, "select * from subscription_user where
		id = '".$subscription_user['id']."'"); //check later
$subscription_user = mysqli_fetch_array($query);		
		

$pdf->SetFont('Arial','',12);
$pdf->Cell(20 ,10,'',0,0);
$pdf->Cell(30 ,10,$subscription_user['sub_type'] ,1,0);
$pdf->Cell(25 ,10,$subscription_user['sub_device'],1,0);
$pdf->Cell(30 ,10,$subscription_user['start_date'],1,0);
$pdf->Cell(30 ,10,$subscription_user['end_date'],1,0);
$pdf->Cell(34 ,10,$subscription_user['sub_fee'],1,1);

//empty row
$pdf->Cell(20 ,10,'',0,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(25 ,10,'',1,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(34 ,10,'',1,1);

//empty row
$pdf->Cell(20 ,10,'',0,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(25 ,10,'',1,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(30 ,10,'',1,0);
$pdf->Cell(34 ,10,'',1,1);

//Total Fee
$pdf->Cell(110 ,20,'',0,0);
$pdf->Cell(25 ,10,'Total Fee',0,0);
$pdf->Cell(4 ,10,'RM',0,0);
$pdf->Cell(10 ,10,$subscription_user['sub_fee'],0,0,'R');//end of line

$pdf->Output();
?>