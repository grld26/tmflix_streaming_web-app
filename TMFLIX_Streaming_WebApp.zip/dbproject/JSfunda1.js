//Javascript automatically iterates/add 1 to the record count everytime a new record is added
//This javascript feature is uneditable to ensure the consistency of the record count
//Accesses the id & contents of the series record that corresponds to its data
let id = $("input[name*='series_id']")
id.attr("readonly","readonly");


$(".btnedit").click( e =>{
    let textvalues = displayData(e);
    let seriesname = $("input[name*='series_name']");
    let seriesgenre = $("input[name*='series_genre']");
    let seriescast = $("input[name*='series_cast']");
    let seriesdirector = $("input[name*='series_director']");
    id.val(textvalues[0]);
    seriesname.val(textvalues[1]);
    seriesgenre.val(textvalues[2]);
    seriescast.val(textvalues[3]);
    seriesdirector.val(textvalues[4]);
});

//Method to display data
function displayData(e) {
    let id = 0;
    const td = $("#tbody tr td");
    let textvalues = [];

    for (const value of td){
        if(value.dataset.id == e.target.dataset.id){
           textvalues[id++] = value.textContent;
        }
    }
    return textvalues;

}