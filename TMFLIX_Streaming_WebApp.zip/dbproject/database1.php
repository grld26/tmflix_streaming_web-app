<?php

//Method that creates the foundation database 
function Createdb(){
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbproject";

    // Create the connection to database
    $con = mysqli_connect($servername, $username, $password);

    // Check the connection to database
    if (!$con){
        die("Connection Failed : " . mysqli_connect_error());
    }

    // create Database
    $sql = "CREATE DATABASE IF NOT EXISTS $dbname";

    if(mysqli_query($con, $sql)){
        $con = mysqli_connect($servername, $username, $password, $dbname);

        $sql = "
                        CREATE TABLE IF NOT EXISTS series(
                            id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            series_name VARCHAR (60) NOT NULL,
                            series_genre VARCHAR (25) NOT NULL,
                            series_cast VARCHAR (60),
                            series_director VARCHAR (60)
                        );
        ";

        if(mysqli_query($con, $sql)){
            return $con;
        }else{
            echo "Cannot Create table...!";
        }

    }else{
        echo "Error while creating database ". mysqli_error($con);
    }

}
