//Javascript automatically iterates/add 1 to the record count everytime a new record is added
//This javascript feature is uneditable to ensure the consistency of the record count
//Accesses the id & contents of the series record that corresponds to its data
let no = $("input[name*='number']")
no.attr("readonly","readonly");


$(".btnedit").click( e =>{
    let textvalues = displayData(e);
    let seriesid = $("input[name*='series_id']");
    let seriesname = $("input[name*='series_name']");
    let seriesseason = $("input[name*='series_season']");
    let seriesepisode = $("input[name*='series_episode']");
    let serieseptitle = $("input[name*='series_ep_title']");
    no.val(textvalues[0]);
    seriesid.val(textvalues[1]);
    seriesname.val(textvalues[2]);
    seriesseason.val(textvalues[3]);
    seriesepisode.val(textvalues[4]);
    serieseptitle.val(textvalues[5]);
});

//Method to display data
function displayData(e) {
    let no = 0;
    const td = $("#tbody tr td");
    let textvalues = [];

    for (const value of td){
        if(value.dataset.no == e.target.dataset.no){
           textvalues[no++] = value.textContent;
        }
    }
    return textvalues;

}