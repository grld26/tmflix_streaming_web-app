<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
	function myFunction() {
	var x = document.getElementById("myPass");
	if (x.type === "password") {
	  x.type = "text";
	} 
	else{
		x.type = "password";
	}
}
</script>
<meta charset="utf-8">
<title>Registration</title>
<link rel="stylesheet" href="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
</head>
<body>
<?php
require('connect.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])){
        // removes backslashes
	$name = stripslashes($_REQUEST['name']);
	$name = mysqli_real_escape_string($con,$name);
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con,$email);
	$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($con,$username); 
	
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($con,$password);
	$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `users` (name,email,username, password, trn_date)
				VALUES ('$name','$email','$username', '".md5($password)."','$trn_date')";
        $result = mysqli_query($con,$query);
        if($result){
			$last_id = mysqli_insert_id($con);
			echo "<h3>Information saved. <br>Your ID is: " . $last_id ;
			echo "<br/>Click <a href='payment.html'>here</a> to complete registration.</div></h3>";
        }else{
		echo "<div class='tologin'>
			<h3>Username is taken.</h3>
			<br/>Click here to <a href='register.php'>register</a> again</div>";
		}
}else{ 
		
?>
 <h4>Step 1 of 2<h4>
<h1>TMFLIX</h1>
<div>
  <form method="post" action="" >
    <input type="text" name="name" class="formStyle" placeholder="Name" required />
    <input type="email" name="email" class="formStyle" placeholder="Email" required />
	<input type="text" name="username" class="formStyle" placeholder="Username" required />
    <input type="password" id="myPass" name="password" class="formStyle" placeholder="Password" required />
	<div>
		<input type="checkbox" onclick="myFunction()">Show Password
	</div>
	<input type="submit" class="formButton" name="Submit" id="Submit" value="Next">
  </form>
</div>
<?php } ?>
</body>
</html>