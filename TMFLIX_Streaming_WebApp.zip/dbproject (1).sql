-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2021 at 12:16 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(20) NOT NULL,
  `name` varchar(125) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `episode`
--

CREATE TABLE `episode` (
  `no` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  `series_name` varchar(60) NOT NULL,
  `series_season` varchar(10) DEFAULT NULL,
  `series_episode` varchar(10) DEFAULT NULL,
  `series_ep_title` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `episode`
--

INSERT INTO `episode` (`no`, `series_id`, `series_name`, `series_season`, `series_episode`, `series_ep_title`) VALUES
(1, 1, 'Breaking Bad', '1', '1', '\"Pilot\"'),
(2, 1, 'Breaking Bad', '1', '2', '\"Cat\'s in the Bag...\"'),
(3, 1, 'Breaking Bad', '1', '3', '\"...And the Bag\'s in the River\"'),
(4, 1, 'Breaking Bad', '1', '4', '\"Cancer Man\"'),
(5, 1, 'Breaking Bad', '1', '5', '\"Gray Matter\"'),
(6, 1, 'Breaking Bad', '2', '1', '\"Seven Thirty-Seven\"'),
(7, 1, 'Breaking Bad', '2', '2', '\"Grilled\"'),
(8, 1, 'Breaking Bad', '2', '3', '\"Bit by a Dead Bee\"'),
(9, 1, 'Breaking Bad', '2', '4', '\"Down\"'),
(10, 1, 'Breaking Bad', '2', '5', '\"Breakage\"'),
(11, 2, 'Stranger Things', '1', '1', '\"Chapter One: The Vanishing of Will Byers\"'),
(12, 2, 'Stranger Things', '1', '2', '\"Chapter Two: The Weirdo on Maple Street\"'),
(13, 2, 'Stranger Things', '1', '3', '\"Chapter Three: Holly, Jolly\"'),
(14, 2, 'Stranger Things', '1', '4', '\"Chapter Four: The Body\"'),
(15, 2, 'Stranger Things', '1', '5', '\"Chapter Five: The Flea and the Acrobat\"'),
(16, 2, 'Stranger Things', '2', '1', '\"Chapter One: MADMAX\"'),
(17, 2, 'Stranger Things', '2', '2', '\"Chapter Two: Trick or Treat, Freak\"'),
(18, 2, 'Stranger Things', '2', '3', '\"Chapter Three: The Pollywog\"'),
(19, 2, 'Stranger Things', '2', '4', '\"Chapter Four: Will the Wise\"'),
(20, 2, 'Stranger Things', '2', '5', '\"Chapter Five: Dig Dug\"'),
(21, 3, 'Brooklyn Nine-Nine', '1', '1', '\"Pilot\"'),
(22, 3, 'Brooklyn Nine-Nine', '1', '2', '\"The Tagger\"'),
(23, 3, 'Brooklyn Nine-Nine', '1', '3', '\"The Slump\"'),
(24, 3, 'Brooklyn Nine-Nine', '1', '4', '\"M.E. Time\"'),
(25, 3, 'Brooklyn Nine-Nine', '1', '5', '\"The Vulture\"'),
(26, 3, 'Brooklyn Nine-Nine', '2', '1', '\"Undercover\"'),
(27, 3, 'Brooklyn Nine-Nine', '2', '2', '\"Chocolate Milk\"'),
(28, 3, 'Brooklyn Nine-Nine', '2', '3', '\"The Jimmy Jab Games\"'),
(29, 3, 'Brooklyn Nine-Nine', '2', '4', '\"Halloween II\"'),
(30, 3, 'Brooklyn Nine-Nine', '2', '5', '\"The Mole\"'),
(31, 4, '13 Reasons Why', '1', '1', '\"Tape 1, Side A\"'),
(32, 4, '13 Reasons Why', '1', '2', '\"Tape 1, Side B\"'),
(33, 4, '13 Reasons Why', '1', '3', '\"Tape 2, Side A\"'),
(34, 4, '13 Reasons Why', '1', '4', '\"Tape 2, Side B\"'),
(35, 4, '13 Reasons Why', '1', '5', '\"Tape 3, Side A\"'),
(36, 4, '13 Reasons Why', '2', '1', '\"The First Polaroid\"'),
(37, 4, '13 Reasons Why', '2', '2', '\"Two Girls Kissing\"'),
(38, 4, '13 Reasons Why', '2', '3', '\"The Drunk Slut\"'),
(39, 4, '13 Reasons Why', '2', '4', '\"The Second Polaroid\"'),
(40, 4, '13 Reasons Why', '2', '5', '\"The Chalk Machine\"'),
(41, 5, 'The Big Bang Theory', '1', '1', '\"Pilot\"'),
(42, 5, 'The Big Bang Theory', '1', '2', '\"The Big Bran Hypothesis\"'),
(43, 5, 'The Big Bang Theory', '1', '3', '\"The Fuzzy Boots Corollary\"'),
(44, 5, 'The Big Bang Theory', '1', '4', '\"The Luminous Fish Effect\"'),
(45, 5, 'The Big Bang Theory', '1', '5', '\"The Hamburger Postulate\"'),
(46, 5, 'The Big Bang Theory', '2', '1', '\"The Bad Fish Paradigm\"'),
(47, 5, 'The Big Bang Theory', '2', '2', '\"The Codpiece Topology\"'),
(48, 5, 'The Big Bang Theory', '2', '3', '\"The Barbarian Sublimation\"'),
(49, 5, 'The Big Bang Theory', '2', '4', '\"The Griffin Equivalency\"'),
(50, 5, 'The Big Bang Theory', '2', '5', '\"The Euclid Alternative\"');

-- --------------------------------------------------------

--
-- Table structure for table `series`
--

CREATE TABLE `series` (
  `id` int(11) NOT NULL,
  `series_name` varchar(60) NOT NULL,
  `series_genre` varchar(25) NOT NULL,
  `series_cast` varchar(60) DEFAULT NULL,
  `series_director` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `series`
--

INSERT INTO `series` (`id`, `series_name`, `series_genre`, `series_cast`, `series_director`) VALUES
(1, 'Breaking Bad', 'Crime', 'Bryan Cranston', 'Vince Gilligan'),
(2, 'Stranger Things', 'Sci-Fi', 'Millie Bobby Brown', 'The Duffer Brothers'),
(3, 'Brooklyn Nine-Nine', 'Sitcom', 'Andy Samberg', 'Dan Goor, Michael Schur'),
(4, '13 Reasons Why', 'Mystery', 'Dylan Minette', 'Brian Yorkey'),
(5, 'The Big Bang Theory', 'Sitcom', 'Johnny Galecki', 'Mark Cendrowski'),
(6, 'Emily in Paris', 'Comedy', 'Lily Collins', 'Andrew Fleming'),
(7, 'Peaky Blinders', 'Historical Fiction', 'Cillian Murphy', 'Otto Bathurst');

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE `subscription` (
  `sub_id` int(11) NOT NULL,
  `sub_device` varchar(125) NOT NULL,
  `sub_type` varchar(125) NOT NULL,
  `sub_fee` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`sub_id`, `sub_device`, `sub_type`, `sub_fee`) VALUES
(1, 'multiple ', 'monthly', 39),
(2, 'one ', 'monthly', 17),
(3, 'one (free)', 'trial', 0);

-- --------------------------------------------------------

--
-- Table structure for table `subscription_user`
--

CREATE TABLE `subscription_user` (
  `id` int(125) NOT NULL,
  `receipt_id` int(11) NOT NULL,
  `sub_device` varchar(125) NOT NULL,
  `sub_type` varchar(125) NOT NULL,
  `sub_fee` float NOT NULL,
  `start_date` date NOT NULL DEFAULT current_timestamp(),
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscription_user`
--

INSERT INTO `subscription_user` (`id`, `receipt_id`, `sub_device`, `sub_type`, `sub_fee`, `start_date`, `end_date`) VALUES
(94, 32, 'multiple ', 'monthly', 39, '2021-07-04', '2021-08-04'),
(0, 33, '', '', 0, '2021-07-04', '2021-08-04'),
(95, 34, 'phone', 'monthly', 17, '2021-07-06', '2021-08-06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `name` varchar(125) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `trn_date`) VALUES
(94, 'Bernedette Imelia Binti Collins', '69219', '69219@siswa.unimas.my', '202cb962ac59075b964b07152d234b70', '2021-07-04'),
(95, 'Jay', 'ab123', 'pbcrispywaffles@gmail.com', '202cb962ac59075b964b07152d234b70', '2021-07-06');

-- --------------------------------------------------------

--
-- Table structure for table `views`
--

CREATE TABLE `views` (
  `id` int(11) NOT NULL,
  `series_name` varchar(60) NOT NULL,
  `view_count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `views`
--

INSERT INTO `views` (`id`, `series_name`, `view_count`) VALUES
(1, 'Breaking Bad', 6),
(2, 'Stranger Things', 3),
(3, 'Brooklyn Nine-Nine', 1),
(4, '13 Reasons Why', 1),
(5, 'The Big Bang Theory', 4),
(6, 'Emily in Paris', 0),
(7, 'Peaky Blinders', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `episode`
--
ALTER TABLE `episode`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `series`
--
ALTER TABLE `series`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription_user`
--
ALTER TABLE `subscription_user`
  ADD UNIQUE KEY `receipt_id` (`receipt_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `episode`
--
ALTER TABLE `episode`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `series`
--
ALTER TABLE `series`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subscription_user`
--
ALTER TABLE `subscription_user`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `views`
--
ALTER TABLE `views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
